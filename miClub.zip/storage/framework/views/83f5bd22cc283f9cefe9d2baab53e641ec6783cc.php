<?php $__env->startSection('nosotros'); ?>


<h4>Create post</h4>
<form id="save_post" method="post" action="<?php echo e(URL::to('/')); ?>/person">
  <?php echo e(csrf_field()); ?>

  <div>
    <p>Title</p>
    <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>">
  </div>
  
  <div>
    <p>Body</p>
    <textarea id="lastname" name="lastname"><?php echo e(old('lastname')); ?></textarea>
  </div>
  
  <div>
    <input type="submit" value="Save">
  </div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\miClub\resources\views/home/person.blade.php ENDPATH**/ ?>