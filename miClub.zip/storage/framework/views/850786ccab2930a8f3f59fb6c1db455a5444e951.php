  	<p>Buscar post</p>
  <form class="" action="index" method="get">
          <?php echo csrf_field(); ?>

       <div class="que-pensas">

         <input type="text" name="name" id="search">
       </div>
      </form>
<?php /**PATH C:\PHP\miClub\resources\views/partials/busquedaPost.blade.php ENDPATH**/ ?>