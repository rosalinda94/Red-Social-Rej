  <?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/logged/publicar.css')); ?>" rel="stylesheet">
  <?php $__env->stopPush(); ?>

<article class="publicar">
  <form class="" action="index" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

 <div class="que-pensas">
   <a class="cuadrado2" href="profile"><img id="fotoPerfil2" src="<?php echo e(Storage::url(Auth::user()->person->avatar)); ?>"  alt=""></a>
   <textarea name="body" rows="1" cols="60" class="comentario" placeholder="<?php echo e(Auth::user()->name); ?>, qué queres escribir hoy?"></textarea>
 </div>

 <div class="que-publicar">
   <div class="subiFoto">
     <label for="avatar" class="labelAvatar"><?php echo e(__('Compartí tus imagenes')); ?></label>
         <input style='display:none' id="avatar" type="file" class=" <?php if ($errors->has('avatar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('avatar'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" accept="image/*" name="avatar" value="<?php echo e(old('avatar')); ?>" required autocomplete="avatar" autofocus>

         <?php if ($errors->has('avatar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('avatar'); ?>
             <span class="invalid-feedback" role="alert">
                 <strong><?php echo e($message); ?></strong>
             </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
   </div>

      <div class="etiqueta">
   <select  id="etiqueta" name="etiqueta"  >
     <option disabled selected>Etiquetar a </option>
     <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
     <option id="etiqueta" name="etiqueta"  value="<?php echo e($user->id); ?>"> <?php echo e($user->name); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <option>no hay amigos</option>
   <?php endif; ?>
   </select>
   </div>
   <div class="actividad">
   <select id="actividad" name="actividad" >
     <option disabled selected>Actividad deportiva  </option>

        <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <option id="actividad" name="actividad" value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <option>No existen actividades deportivas</option>
   <?php endif; ?>
   </select>
    </div>
   <button type="submit" class="botonPublicar"><i class="fas fa-check"></i></button>
 </div>
</form>

</article>
<?php /**PATH C:\xampp\htdocs\miClub\resources\views/partials/posteo.blade.php ENDPATH**/ ?>