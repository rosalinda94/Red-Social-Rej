 <li class="nav-item dropdown">
        <a id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"  v-pre><i id="notificaciones" style="color: white" class="fas fa-bell"></i>
        </a>
      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
          
           	 <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

           	 <?php if(auth()->id()==$post->etiqueta_id && $post->etiqueta_id !=''): ?>
     		<a class="dropdown-item" type="submit" href="filtrarNotificacion?id=<?php echo e($post->id); ?> " >El usuario <b><?php echo e($post->user->name); ?> </b>Te etiqueto en una publicacion
            </a>
            <?php endif; ?>

         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
         <a class="dropdown-item" >No existen notificaciones</a>
 
   <?php endif; ?>
           
        </div>
</li>
<?php /**PATH C:\PHP\miClub\resources\views/partials/notificaciones.blade.php ENDPATH**/ ?>