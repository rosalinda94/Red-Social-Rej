<?php $__env->startSection('content'); ?>

  <body class="body">

    <link href="<?php echo e(asset('css/home.css')); ?>" rel="stylesheet">
    <div class="home-logueado">
    <section class="aside">
      <article class="profile-aside">
         <a href="profile.php">
          <img src="storage\<?php echo e(Auth::user()->person->avatar); ?>"  alt="" width="50px">
        </a>

        <!-- poner el nombre del usuario -->
        <a class="profile-picture" href="profile.php"><h3 class="user-name"> <?php echo e(Auth::user()->name); ?> <span class="caret"></span></h3></a>
      </article>

      <article class="Listado-completo">
        <h1>home</h1>
         <?php echo $__env->make('/home.group', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  ;
         <!-- Incluyo la seccion de los grupos@include('/home.group')  -->
      </article>
    </section>

<!-- inicio home principal -->

    <section class="principal">
      <article class="publicar">
        <dir class="que-pensas">
           <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('register')); ?>" >
             <a class="profile-picture" href="profile.php" ><img src="storage\<?php echo e(Auth::user()->person->avatar); ?>"  alt=""></a>
             <textarea name="name" rows="1" cols="60" class="comentario" placeholder="¿Qué estas pensando...?"></textarea>

           </form>        

        </dir>

        
      <article class="publicacion">
        <div class="">
          <a class="profile-picture" href="profile.php"><img src="img/foto-perfil.jpg" alt=""></a>
          <!-- poner el nombre del usuario -->
          <p>Maria Juana Perez</p>
          <p>horario</p>
        </div>
        <div class="publicacion-user">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        </div>
        <div class="publicacion-imagenes">
          <img src="img/img1.png" alt="">
          <img src="img/img1.png" alt="">
          <img src="img/img1.png" alt="">
          <img src="img/img1.png" alt="">
        </div>
        <div class="publicacion-reaccion">
          <ul>
            <li>personas que le gusta</li>
            <li>x comentarios</li>
          </ul>
        </div>
        <div class="publicacion-reaccionar">
          <ul>
            <li>Me gusta</li>
            <li>Comentar</li>
          </ul>
        </div>
        <div class="publicacion-comentarios">
          <a class="profile-picture" href="profile.php"><img src="img/foto-perfil.jpg" alt=""></a>
          <div class="">
            <h5>nombre usuario</h5>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et</p>
            <ul>
              <li>Me gusta</li>
              <li>Responder</li>
              <li>fecha/hora</li>
            </ul>
          </div>
        </div>
        <textarea name="name" rows="2" cols="70" placeholder="Escribí aca tu comentario..."></textarea>
        <button type="submit" name="ok">1</button>
      </article>
    </section>

    <section class="aside2">
      <article class="publicidad">
        publicidad
      </article>
      <article class="calendario">
        calendario
      </article>
    </section>
    </div>
  </body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\miClub\resources\views/home/home.blade.php ENDPATH**/ ?>