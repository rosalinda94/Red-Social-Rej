
    <div class="container">
        <form method="Post" action="/home">
            <input type="text" name="title">
            <input type="text" name="body">
            <button type="submit">Crear post</button>
        </form>
    </div>
<?php /**PATH /var/www/html/miClub/resources/views//home/post/create.blade.php ENDPATH**/ ?>