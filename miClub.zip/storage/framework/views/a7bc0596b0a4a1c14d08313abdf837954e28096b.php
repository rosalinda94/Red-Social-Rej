
<div class="list-group">
    <button id='botonCategorias' type="button" class="list-group-item list-group-item-action active">
      Categorias
    </button>
    <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <!-- <form class="" action="/filtrarCategoria" method="post"> -->
      <?php echo csrf_field(); ?>
      <!-- <input type="hidden" name="id" value="<?php echo e($group->id); ?>"> -->
      <a type="submit" href="filtrarCategoria?id=<?php echo e($group->id); ?>" class="list-group-item list-group-item-action"><i class="<?php echo e($group->icon); ?>"></i><?php echo e($group->name); ?></a>
      <!-- <button type="submit" class="list-group-item list-group-item-action"><i class="<?php echo e($group->icon); ?>"></i><?php echo e($group->name); ?></button> -->
    <!-- </form> -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <li>no hay grupos</li>
    <?php endif; ?>
</div>
<?php /**PATH C:\PHP\miClub\resources\views/partials/grupos.blade.php ENDPATH**/ ?>