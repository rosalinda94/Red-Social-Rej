<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('css/logged/profileLogged.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Esto es la portada  -->
  <div class="perfilLogueado">
  	    <?php if(Auth::user()->additional && Auth::user()->additional->image): ?>
<section class="portadaUsuario" 
style="background-image: url('<?php echo e(Storage::url(Auth::user()->additional->image)); ?>')">
<?php else: ?>
<section class="portadaUsuario" >
  <?php endif; ?>
<div class="infoUsuario">
  <div class="cuadrado4">
    <img id="fotoPerfil4" src="<?php echo e(Storage::url(Auth::user()->person->avatar)); ?>"  alt="">
  </div>
  <h3 class="user-name"><?php echo e(Auth::user()->person->name); ?> <?php echo e(Auth::user()->person->lastName); ?></h3>
</div>
</section>

  <!-- Esto es para agregar posts -->
<section class="posteosUsuario">


<article class="posteos">
      <?php echo $__env->make('partials.labels', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</article>
</section>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PHP\miClub\resources\views/home/labels.blade.php ENDPATH**/ ?>