<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
        <img src="<?php echo e(asset('/img/publicidad2.jpg')); ?>" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="<?php echo e(asset('/img/publicidad1.jpg')); ?>" class="d-block w-100" alt="...">
    </div>
</div>
<?php /**PATH C:\PHP\miClub\resources\views/partials/publicidad.blade.php ENDPATH**/ ?>