<?php $__env->startSection('title', 'Contact'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <form class="form-horizontal">
            <fieldset>
                <div class="form-group">
                    <label for="titulo" class="col-lg-2 control-label">Título</label>
                    <div class="col-lg-10">
                        <input type="text" class="form-control" id="titulo" placeholder="titulo">
                    </div>
                </div>
                <div class="form-group">
                    <label for="contenido" class="col-lg-2 control-label">Contenido</label>
                    <div class="col-lg-10">
                        <textarea class="form-control" rows="5" id="contenido"></textarea>
                        <span class="help-block">Envia tu mensaje</span>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-lg-10 col-lg-offset-2">
                    <button class="btn btn-default">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Enviar</button>
                </div>
            </fieldset>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\miClub\resources\views/mensaje/create.blade.php ENDPATH**/ ?>