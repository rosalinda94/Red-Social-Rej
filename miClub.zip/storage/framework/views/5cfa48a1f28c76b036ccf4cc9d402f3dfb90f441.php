<?php $__env->startSection('content'); ?>
<div class="container">
 <div class="row">
 <div class="col-md-10 col-md-offset-1">
 <?php echo Form::open(['route' => 'person.store', 'method' => 'post', 'novalidate']); ?>

                <div class="form-group">
                      <?php echo Form::label('full_name', 'Nombre'); ?>

                      <?php echo Form::text('name', null, ['class' => 'form-control' , 'required' => 'required']); ?>

                  </div>
                  <div class="form-group">
                      <?php echo Form::label('lastName', 'Descripci&oacute;n'); ?>

                      <?php echo Form::text('lastName', null, ['class' => 'form-control' , 'required' => 'required']); ?>

                  </div>
                <div class="form-group">
                      <?php echo Form::submit('Enviar', ['class' => 'btn btn-success ' ] ); ?>

                  </div>
            <?php echo Form::close(); ?>

 </div>
 </div>
</div>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\miClub\resources\views/new.blade.php ENDPATH**/ ?>