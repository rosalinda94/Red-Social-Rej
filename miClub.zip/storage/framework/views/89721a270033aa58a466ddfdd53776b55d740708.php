<h1>Registrar</h1>
<?php echo Form::open(['route' => 'terceros.store']); ?>

<p>Aqui van los campos</p>

<div class="form-group">
	<?php echo Form::button('guardar', ['type' => 'submit', 'class' => 'btn btn-primary']); ?>


</div>

<?php echo Form::close(); ?><?php /**PATH C:\xampp\htdocs\miClub\resources\views/terceros/create.blade.php ENDPATH**/ ?>