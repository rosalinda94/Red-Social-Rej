<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('css/logged/profileLogged.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- Esto es la portada  -->
  <div class="perfilLogueado">
    <?php if(Auth::user()->additional && Auth::user()->additional->image): ?>
<section class="portadaUsuario" 
style="background-image: url('<?php echo e(Storage::url(Auth::user()->additional->image)); ?>')">
<?php else: ?>
<section class="portadaUsuario" >
  <?php endif; ?>
<div class="infoUsuario">
  <div class="cuadrado3">
    <img id="fotoPerfil3" src="<?php echo e(Storage::url(Auth::user()->person->avatar)); ?>"  alt="">
  </div>
  <h3 class="user-name"><?php echo e(Auth::user()->person->name); ?> <?php echo e(Auth::user()->person->lastName); ?></h3>
</div>

  <?php if(Auth::user()->additional && Auth::user()->additional->image): ?>


  <form class="fotoPortada" action="/profile/portada" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label for="portada" class="labelAvatar"><?php echo e(__('Foto de portada')); ?></label>
    <input style='display: none;' id="portada" type="file" accept="image/*" name="portada" value="<?php echo e(old('portada')); ?>" required autocomplete="portada" autofocus>
    <button class="botonPortada">Cambiar imagen</button>
  </form> 
  <?php else: ?>
    <form class="fotoPortada" action="/profile/portada" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label for="portada" class="labelAvatar"><?php echo e(__('Foto de portada')); ?></label>
    <input style='display: none;' id="portada" type="file" accept="image/*" name="portada" value="<?php echo e(old('portada')); ?>" required autocomplete="portada" autofocus>
    <button class="botonPortada">Enviar</button>

  <?php endif; ?>

</section>

<div class="todoUsuario">

<section class="datosUsuario">
  <!-- Esto es para registrar los datos adicionales -->
<article class="infoGeneral">

    <h4>Datos Adicionales</h4>
   <?php echo $__env->make('partials.additional', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</article>

  <!-- Esto es para mostrar la imagen abajo -->
<article class="fotosUsuario">

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(auth()->id()==$post->user_id): ?>
      <div class="contenedorFoto">
    <img class="imgPublicacion" src="/storage/<?php echo e($post->image); ?>"  alt="" >
      </div>
    <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</article>

</section>

  <!-- Esto es para agregar posts -->
<section class="posteosUsuario">
<article class="posteos">
      <?php echo $__env->make('partials.posteo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</article>


  <!-- Esto es para ver los posts -->
<article class="posteos">
      <?php echo $__env->make('partials.perfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</article>
</section>
<script src="<?php echo e(asset('js/profile.js')); ?>" defer></script>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PHP\miClub\resources\views/home/profile.blade.php ENDPATH**/ ?>