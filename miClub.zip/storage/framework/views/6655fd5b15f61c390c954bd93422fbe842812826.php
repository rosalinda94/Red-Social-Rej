  <?php $__empty_1 = true; $__currentLoopData = $additionals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
   
      <?php if(auth()->id()==$additional->user_id && $additional->status!=''): ?>
  <li>Situación sentimental: <?php echo e($additional->status); ?> </li>

       <li>Ciudad: <?php echo e($additional->city); ?></li>
  <?php endif; ?>

    
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 

      <form action="profile/create" method="POST">

    <?php echo e(csrf_field()); ?>

     <div class="form-group">
    <label for="exampleFormControlSelect1">Ciudad
</label>
    <select class="form-control"  name="city"  id="exampleFormControlSelect1">
      <option name="city" required value="Buenos Aires">Buenos Aires</option>
      <option name="city" required value="Mar del Plata">Mar del Plata</option>
      <option name="city" required value="Mendoza">Mendoza</option>
      <option name="city" required value="Bariloche">Bariloche</option>

    </select>
  </div>
      <div class="form-group">
    <label for="exampleFormControlSelect1">Situación sentimental
</label>
    <select class="form-control"  name="status"  id="exampleFormControlSelect1">
      <option name="status" required value="Soltera">Soltera</option>
      <option name="status" required value="Casada">Casada</option>
      <option name="status" required value="Viuda">Viuda</option>
      <option name="status" required value="Divorciada">Divorciada</option>

    </select>
  </div>
      <button type="submit">Enviar</button>
  </form>     
      <?php endif; ?><?php /**PATH C:\xampp\htdocs\miClub\resources\views/partials/register.blade.php ENDPATH**/ ?>