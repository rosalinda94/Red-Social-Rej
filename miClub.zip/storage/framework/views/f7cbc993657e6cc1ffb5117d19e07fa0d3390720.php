<h1><?php echo e($title); ?></h1>
<ul>
<?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<li> <?php echo e($group ->name); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<li>no hay grupos</li>
<?php endif; ?>
</ul><?php /**PATH C:\xampp\htdocs\miClub\resources\views//home/group.blade.php ENDPATH**/ ?>