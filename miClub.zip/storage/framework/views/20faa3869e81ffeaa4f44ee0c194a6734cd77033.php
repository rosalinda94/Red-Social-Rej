
    <div class="container">
        <form method="Post" action="post.store">
            <input type="text" name="title">
            <input type="text" name="body">
            <button type="submit">Crear post</button>
        </form>
    </div><?php /**PATH C:\xampp\htdocs\miClub\resources\views//home/post/create.blade.php ENDPATH**/ ?>