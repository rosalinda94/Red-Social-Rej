<?php $__env->startSection('content'); ?>

  <body class="body">

    <link href="<?php echo e(asset('css/home.css')); ?>" rel="stylesheet">
    <div class="home-logueado">

<!-- inicio home principal -->

    <section class="principal">
      <?php echo $__env->make('partials.posteo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


      <article class="publicacion">
      <ul>
      	<!-- pasar solo estooo -->
			<?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<article class="publicacion">
			    <div class="">
			        <img src="storage\<?php echo e($post->image); ?>"  alt="" width="50px">

			        <b><?php echo e($post->user->name); ?></b>
              <p><?php echo e($post->created_at); ?></p>

			        </div>
			        <div class="publicacion-user">

			        <p><?php echo e($post->body); ?></p>

              <i class="far fa-thumbs-up"> Me gusta</i>
              <i class="far fa-thumbs-down"> No me gusta</i>
              <i class="fas fa-share"> Compartir</i>
              <i><?=
              $numero_aleatorio = rand(1,5) . ' veces compartidos'; ?></i>
              <div class="form-row">
              <div class="form-group col-md-12" style="justify-content: center">
                <input type="text" class="form-control" id="comment" placeholder="Deja aca tu comentario">
              </div>

			        </div>
			      </article>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<li>no hay posts</li>
			<?php endif; ?>
		<!-- pasar solo estooo -->
</ul>


       </article>
    </section>


    </div>
  </body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/miClub/resources/views//home/index.blade.php ENDPATH**/ ?>