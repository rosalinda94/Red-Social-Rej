 <article class="publicacion">
      <ul>
      	<!-- pasar solo estooo -->
			<?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<article class="publicacion">
			    <div class="">

              <a class="profile-picture" href="profile/profile"><img src="storage\<?php echo e($post->user->person->avatar); ?>"  alt="" width="50px"></a>
			        <b><?php echo e($post->user->name); ?></b><br>
              <?php if(isset($post->group)): ?>
              <p>Este post pertenece a la categoria :<b> <?php echo e($post->group->name); ?></b></p>

              <?php endif; ?>


              <p><?php echo e($post->body); ?></p>
              <img src="storage\<?php echo e($post->image); ?>"  alt="" width="300px" height="300px">
              <br> <br>
			        </div>
			        <div class="publicacion-user">


              <i class="far fa-thumbs-up"> Me gusta</i>
              <i class="far fa-thumbs-down"> No me gusta</i>
              <i class="fas fa-share">  Compartir</i>
              <i><?=
              $numero_aleatorio = rand(1,5) . ' veces compartidos'; ?></i>
              <?php if(auth()->id()==$post->user_id): ?>
                <form action="<?php echo e(URL::to('/')); ?>/post/<?php echo e($post->id); ?>" method="POST">
                   <?php echo e(csrf_field()); ?>

                   <?php echo e(method_field('DELETE')); ?>

                   <button type="submit">Eliminar</button>
                 </form>

              <?php endif; ?>

              <div class="form-row">
              <div class="form-group col-md-12" style="justify-content: center">
                <input type="text" class="form-control" id="comment" placeholder="Deja aca tu comentario">
              </div>

			        </div>
			      </article>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<li><br>No existen posteos </b><img src="/img/triste.jpg" width="150px"></li>
			<?php endif; ?>
		<!-- pasar solo estooo -->
</ul>

      <?php echo e($posts->appends(request()->query())->links()); ?>


       </article>
<?php /**PATH /var/www/html/miClub/resources/views/partials/publicaciones.blade.php ENDPATH**/ ?>