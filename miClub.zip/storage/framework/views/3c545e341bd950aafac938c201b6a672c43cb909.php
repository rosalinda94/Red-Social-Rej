 <article class="publicacion">
      <ul>
      	<!-- pasar solo estooo -->
			<?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<article class="publicacion">
			    <div class="">


              <a class="profile-picture" href="profile/profile"><img src="<?php echo e(Storage::url(Auth::user()->person->avatar)); ?>"  alt="" width="50px"></a>


			        <b><?php echo e($post->user->name); ?></b><br>
              <?php if(isset($post->group)): ?>
              <p>Este post pertenece a la categoria :<b> <?php echo e($post->group->name); ?></b></p>

              <?php endif; ?>


              <p><?php echo e($post->body); ?></p>

              <img src="/storage/<?php echo e($post->image); ?>"  alt="" width="300px" height="300px">
              <br> <br>
			        </div>
                <div id='publicacion-user' class="publicacion-user">
                  <div class="botones">
                    <a id='like-button' class='like-button' href="#"><i class="far fa-thumbs-up"> Me gusta</i></a>
                    <a id='dislike-button' class='dislike-button' href="#"><i class="far fa-thumbs-down"> No me gusta</i></a>
                    <a id='share-button' class='share-button' href="#"><i class="fas fa-share">  Compartir</i></a>
                  </div>
                  <div id='interaccion' class="interaccion">
                    <!-- Aca va la informacion sobre la interaccion del usuario con el posteo -->
                    <i><?=
                    $numero_aleatorio = rand(1,5) . ' veces compartidos'; ?></i>
                  </div>
                </div>

              <?php if(auth()->id()==$post->user_id): ?>
                <form action="<?php echo e(URL::to('/')); ?>/post/<?php echo e($post->id); ?>" method="POST">
                   <?php echo e(csrf_field()); ?>

                   <?php echo e(method_field('DELETE')); ?>

                   <button type="submit">Eliminar</button>
                 </form>
              <?php endif; ?>

                  <?php $__empty_2 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                  <?php if($post->id == $comment->post_id): ?>
                 <b><?php echo e($post->user->name); ?></b> 
                <p><?php echo e($comment->body); ?></p>
              <?php endif; ?>
                   

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                <?php endif; ?>
              <div class="form-row">
              <div class="form-group col-md-12" style="justify-content: center">
                <form action="comment/create" method="POST">
                   <?php echo e(csrf_field()); ?>

                   <input type="hidden" value='1' name="postId">
                    <input type="text" class="form-control" id="body" name="body" placeholder="Deja aca tu comentario">
                 </form>
              </div>

			        </div>
			      </article>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<li><br>No existen posteos </b><img src="/img/triste.jpg" width="150px"></li>
			<?php endif; ?>
		<!-- pasar solo estooo -->
</ul>

      <?php echo e($posts->appends(request()->query())->links()); ?>


       </article>
<?php /**PATH C:\PHP\miClub\resources\views/partials/publicaciones.blade.php ENDPATH**/ ?>