
<div class="list-group">
    <a id='botonCategorias' type="button" href="/index" class="catTitulo" style="text-align: center">
      Categorias
    </a>
    <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <?php echo csrf_field(); ?>
      <a type="submit" href="filtrarCategoria?id=<?php echo e($group->id); ?>" class="cat"><i class="<?php echo e($group->icon); ?>"></i><?php echo e($group->name); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <li>no hay grupos</li>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\miClub\resources\views/partials/grupos.blade.php ENDPATH**/ ?>