<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('css/logged/publicacion.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

 <article class="publicacion">
      <ul class="publicaciones">
        <!-- pasar solo estooo -->
      <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <?php if(auth()->id()==$post->user_id): ?>
      <article class="publicacion">
        <?php if(auth()->id()==$post->user_id): ?>
          <form class="eliminar" action="<?php echo e(URL::to('/')); ?>/post/<?php echo e($post->id); ?>" method="POST">
             <?php echo e(csrf_field()); ?>

             <?php echo e(method_field('DELETE')); ?>

             <button id="eliminar" type="submit"><i class="fas fa-trash-alt"></i></button>
           </form>
        <?php endif; ?>
          <div class="quienPublica">
              <a class="cuadrado5" href="profile"><img id="fotoPerfil5" src="<?php echo e(Storage::url($post->user->person->avatar)); ?>"  alt="" width="50px"></a>
              <div class="quienPublicaInfo">
                <h4 class="userName" ><?php echo e($post->user->name); ?></h4>
                <?php if(isset($post->group)): ?>
                <p>Este post pertenece a la categoria :<b> <?php echo e($post->group->name); ?></b></p>
                <?php endif; ?>
              </div>
            </div>

              <p class="textoPublicacion"><?php echo e($post->body); ?></p>

              <img class="imgPublicacion" src="/storage/<?php echo e($post->image); ?>"  alt="">
              <br> <br>

                <div id='publicacion-user' class="publicacion-user">
             <?php echo $__env->make('partials.like', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


               <?php echo $__env->make('partials.comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <div class="form-row">
              <div class="form-group col-md-12" style="justify-content: center">

                <form action="comment/create" method="POST">

                   <?php echo e(csrf_field()); ?>


                   <input type="hidden" value="<?= $post->id ?>" name="postId">
                    <input type="text" class="" id="bodyComentarios" name="body" placeholder="Deja acá tu comentario">
                 </form>
              </div>

              </div>
            </article>
<?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <li class="noPost">No existen posteos </b><i class="fas fa-sad-cry"></i></li>
      <?php endif; ?>
    <!-- pasar solo estooo -->
</ul>

      <?php echo e($posts->appends(request()->query())->links()); ?>


      <script src="<?php echo e(asset('js/home.js')); ?>" defer></script>

       </article>
<?php /**PATH C:\PHP\miClub\resources\views/partials/perfil.blade.php ENDPATH**/ ?>