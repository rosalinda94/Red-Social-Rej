 <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php if($post->id == $comment->post_id): ?>
    <div class="totalComentario">
    <a class="cuadrado5" href="profile"><img id="fotoPerfil6"  src="storage\<?php echo e($comment->user->person->avatar); ?>"  alt=""></a>
    <div class="comentarioX">
      <b class="userName2"><?php echo e($comment->user->name); ?></b>
      <p class="queComento"><?php echo e($comment->body); ?></p>
    </div>
    <?php if(auth()->id()==$comment->user_id): ?>
      <form class="eliminar" action="<?php echo e(URL::to('/')); ?>/comment/<?php echo e($comment->id); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('DELETE')); ?>

        <button id="eliminarComentario" type="submit"><i id="tacho" class="fas fa-trash-alt"></i></button>
      </form>
      <script src="<?php echo e(asset('js/home.js')); ?>" defer></script>
    <?php endif; ?>
      </div>
  <?php endif; ?>


  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <?php endif; ?>
<?php /**PATH C:\PHP\miClub\resources\views/partials/comment.blade.php ENDPATH**/ ?>