<?php $__env->startSection('content'); ?>
  <body class="body">

    <?php echo $__env->make('home.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link href="<?php echo e(asset('css/home.css')); ?>" rel="stylesheet">
    <div class="home-logueado">

<section class="aside">
      <article class="profile-aside">
       <a class="profile-picture" href="profile/profile"><img src="storage\<?php echo e(Auth::user()->person->avatar); ?>"  alt="" width="50px"> </a>
        <!-- poner el nombre del usuario -->
        <a class="profile-picture" href="profile.php"><h3 class="user-name"><?php echo e(Auth::user()->person->name); ?> <?php echo e(Auth::user()->person->lastName); ?></h3></a>
      </article>

      <article class="Accesos-directos">
          <?php echo $__env->make('partials.grupos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </article>


    </section>
<!-- inicio home principal -->

    <section class="principal">

      <?php echo $__env->make('partials.posteo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('partials.publicaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </section>

<section class="aside2">
      <article class="publicidad">
        <?php echo $__env->make('partials.publicidad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </article>
      <article class="calendario">
        calendario
      </article>
    </section>
    </div>
  </body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/miClub/resources/views/home/index.blade.php ENDPATH**/ ?>