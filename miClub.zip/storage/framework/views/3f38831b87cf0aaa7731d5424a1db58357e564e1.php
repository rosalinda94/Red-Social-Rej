<div id='contenedor_carga' class="">
  <div id='carga' class="">
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\miClub\resources\views/home/loading.blade.php ENDPATH**/ ?>