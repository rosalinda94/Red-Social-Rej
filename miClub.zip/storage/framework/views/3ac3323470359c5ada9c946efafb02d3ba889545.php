<?php $__env->startSection('content'); ?>

  <body class="body">

    <link href="<?php echo e(asset('css/home.css')); ?>" rel="stylesheet">
    <div class="home-logueado">

<!-- inicio home principal -->

    <section class="principal">
       <article class="publicar">
         <form class="" action="post" method="post" enctype="multipart/form-data">
           <?php echo csrf_field(); ?>

        <div class="que-pensas">
          <a class="profile-picture" href="profile.php"><img src="storage\<?php echo e(Auth::user()->person->avatar); ?>"  alt="" width="50px"></a>
          <textarea name="title" rows="1" cols="70" class="comentario" placeholder="Que quieres escribir hoy?   <?php echo e(Auth::user()->name); ?>"></textarea>
          <textarea name="body" rows="1" cols="70" class="comentario" placeholder="Que quieres escribir hoy?   <?php echo e(Auth::user()->name); ?>"></textarea>
        </div>
        <div class="que-publicar">
          <div class="form-group row">
              <label for="avatar" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Foto de perfil')); ?></label>

              <div class="col-md-6">
                  <input style="color:transparent" id="avatar" type="file" class=" <?php if ($errors->has('avatar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('avatar'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" accept="image/*" name="avatar" value="<?php echo e(old('avatar')); ?>" required autocomplete="avatar" autofocus>

                  <?php if ($errors->has('avatar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('avatar'); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
          </div>

          <select class="btn btn-outline-secondary">
            <option disabled selected>Etiquetar a </option>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="fel"> <?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <option>no hay socios</option>
          <?php endif; ?>

          </select>
          <button type="submit" class="btn btn-outline-secondary">Publicar</button>
        </div>
      </form>

      </article>


      <article class="publicacion">
      <ul>
      	<!-- pasar solo estooo -->
			<?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<article class="publicacion">
			    <div class="">
			        <img src="storage\<?php echo e($post->image); ?>"  alt="" width="50px">
			        <b><?php echo e($post->user->name); ?></b>
			        <p><?php echo e($post->create_at); ?></p>
			        </div>
			        <div class="publicacion-user">
			        <p><?php echo e($post->body); ?></p>
              <i class="far fa-thumbs-up"> Me gusta</i>
              <i class="far fa-thumbs-down"> No me gusta</i>
              <i class="fas fa-share"> Compartir</i>
              <i><?=
              $numero_aleatorio = rand(1,5) . ' veces compartidos'; ?></i>
              <div class="form-row">
              <div class="form-group col-md-12" style="justify-content: center">
                <input type="text" class="form-control" id="comment" placeholder="Deja aca tu comentario">
              </div>

			        </div>
			      </article>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<li>no hay posts</li>
			<?php endif; ?>
		<!-- pasar solo estooo -->
</ul>


       </article>
    </section>


    </div>
  </body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/miClub/resources/views//home/post/index.blade.php ENDPATH**/ ?>