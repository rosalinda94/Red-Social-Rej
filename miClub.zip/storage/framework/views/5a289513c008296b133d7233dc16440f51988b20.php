<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Mi Club')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/registracion.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/loading.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/home.js')); ?>" defer></script>



    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/header.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/logged/headerLogged.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/loading.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldPushContent('styles'); ?>

</head>
<body>
    <div id="app">
        <nav id="header"  class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    
                    <img id='logo' src="<?php echo e(asset('/img/logo-blanco.png')); ?>" alt="">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->

                        <?php if(auth()->guard()->guest()): ?><li class="nav-item">
                          <li class="nav-item">
                              <a class="nav-link" href="/#nosotros"><?php echo e(__('Nosotros')); ?></a>
                          </li>
                          <li class="nav-item">
                              <a class="nav-link" href="/#contacto"><?php echo e(__('Contactanos')); ?></a>
                          </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Iniciar sesión')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Registro')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                          <ul class="header-logged">

                            <li class="nav-item">
                              <a class="nav-link" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="<?php echo e(url('home/profile')); ?>"><?php echo e(__('Mi perfil')); ?></a>
                            </li>
                          </ul>
                          <ul>
                            <li class="nav-item dropdown">
                                    <a id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre><i id="notificaciones" class="fas fa-bell"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" >El usuario <?php echo e(Auth::user()->name); ?> Te etiqueto en una publicacion
                                        </a>

                                    </div>
                            </li>

                            <li>
                              <div class="cuadrado">
                                <img id="fotoPerfil" src="<?php echo e(Storage::url(Auth::user()->person->avatar)); ?>"  alt="" width="40px">
                              </div>
                            </li>
                            <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                           onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Cerrar Sesion')); ?>

                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                            </li>
                          </ul>

                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->yieldContent('nosotros'); ?>
        </main>
            <?php echo $__env->yieldContent('footer'); ?>
    </div>

</body>
</html>
<?php /**PATH C:\PHP\miClub\resources\views/layouts/app.blade.php ENDPATH**/ ?>