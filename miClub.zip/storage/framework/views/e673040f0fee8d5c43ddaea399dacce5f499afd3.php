<div id='contenedor_carga' class="">
  <div id='carga' class="">
  </div>
</div>
<div class="container">
<?php /**PATH /var/www/html/miClub/resources/views/home/loading.blade.php ENDPATH**/ ?>