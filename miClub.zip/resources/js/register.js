
function cambiar(){
    var pdrs = document.getElementById('avatar').files[0].name;
    document.getElementById('info').innerHTML = pdrs;
}
