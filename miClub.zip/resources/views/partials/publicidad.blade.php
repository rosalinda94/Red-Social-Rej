<div class="web">
<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
        <img src="{{asset('/img/publicidad2.jpg')}}" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="{{asset('/img/publicidad1.jpg')}}" class="d-block w-100" alt="...">
    </div>
</div>
</div>
</div>

<div class="tablet">
<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
        <img src="{{asset('/img/Banner.png')}}" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="{{asset('/img/Banner2.png')}}" class="d-block w-100" alt="...">
    </div>
</div>
</div>

<div class="celular">
<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
        <img src="{{asset('/img/Banner.png')}}" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="{{asset('/img/Banner2.png')}}" class="d-block w-100" alt="...">
    </div>
</div>
</div>
