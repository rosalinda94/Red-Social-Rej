
   @isset($additional->city)
         <li>Situación sentimental: {{$additional->status}} </li>
         <li>Ciudad: {{$additional->city}}</li>
         <li>Telefono: {{$additional->mobileNumber}} </li>
         <li>Fecha de Nacimiento: {{$additional->date}}</li>
      @else



      <form action="profile/create" method="get">


     <div class="form-group">
    <label class="datos" for="exampleFormControlSelect1">Ciudad</label>
    <select class="form-control"  name="city"  id="exampleFormControlSelect1">
      <option class="datos" disabled selected>Selecciona donde vivis</option>
      <option name="city" required value="Buenos Aires">Buenos Aires</option>
      <option name="city" required value="Mar del Plata">Mar del Plata</option>
      <option name="city" required value="Mendoza">Mendoza</option>
      <option name="city" required value="Bariloche">Bariloche</option>
    </select>
    </div>

      <div class="form-group">
    <label class="datos" for="exampleFormControlSelect1">Situación sentimental</label>
    <select class="form-control"  name="status"  id="exampleFormControlSelect1">
      <option  style="background-color: black" disabled selected>Selecciona tu situación sentimental</option>
      <option name="status" required value="Soltera">Soltera</option>
      <option name="status" required value="Casada">Casada</option>
      <option name="status" required value="Viuda">Viuda</option>
      <option name="status" required value="Divorciada">Divorciada</option>
    </select>
    </div>

    <div class="form-group">
    <label class="datos" for="exampleFormControlSelect1">Numero de Telefono</label>
       <input id="mobileNumber" required type="text" class="form-control" name="mobileNumber" placeholder=" 011 - 11111111">
    </div>
      <div class="datos" class="form-group">
    <label for="exampleFormControlSelect1">Fecha de Nacimiento</label>
       <input id="date" type="date" required class="form-control" name="date"   autocomple>
    </div>
      <button  id='submit' type="submit" class="botonPublicar" style="width: 100%" >Enviar</button>
  </form>
      @endisset
